; mess 
; --------
; febnug

org 100h

mov al,13h
int 10h

a:
mov cl,07eh
b:
inc cx
les ax,[bx]
mov ah,0cdh
mul di
mov al,dh
mul cl
xchg ax,dx
mul cl
xor ah,cl
test dh,ah
jnz b
shr ax,0ch
stosb
jmp a
